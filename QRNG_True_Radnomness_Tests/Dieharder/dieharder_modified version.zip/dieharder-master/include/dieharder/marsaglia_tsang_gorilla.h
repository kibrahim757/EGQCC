/*
 * Hopefully this is a valid default initialization of the template test.
 */

static Dtest marsaglia_tsang_gorilla_data = {
  "Marsaglia and Tsang Gorilla Test",
  "\n\
#==================================================================\n\
#               Marsaglia and Tsang Gorilla Test\n\
#\n\
# THIS TEST IS UNDER CONSTRUCTION!  It does not work yet, and what\n\
# is presented is, in fact, the output of the test template.\n\
# Note that the second revision number will bump by one when this\n\
# test is completed -- check back later!\n\
#==================================================================\n",
  100,
  100000
};

static Dtest *dtest = &marsaglia_tsang_gorilla_data;
